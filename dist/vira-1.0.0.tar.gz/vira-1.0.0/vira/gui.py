from vira.display_win import display


def gui():
    """Welcome to COVIDATA"""
    display()
